
import logo from "../../../assets/logo.png"
import thumbnail from "../../../assets/thumbnail.png"


const slug = 'recent-products-block';

export const dashboardInfo = (info) => {
  const { version, } = info;



  return {
    name: `Recent Products Block`,
    displayName: `Recent Products Block for WooCommerce – Display Latest WooCommerce Products.`,
    description:
      "Recent Products Block for WooCommerce is a block plugin by which you can showcase your WooCommerce Recently added product in block Widgets, or anywhere in the block editor area.",
    slug,
    version,
    displayOurPlugins: true,
    media: {
      logo: `${logo}`,
      // banner: ``,
      thumbnail: `${thumbnail}`
    },
    pages: {

    },

    changelogs: [
      {
        version: '2.0.3 –- 02 June, 2026 ',
        type: "update",
        list: [
          "Updated plugin guideline compliance issues.",
          "Improved readme structure and formatting."
        ]
      },
      {
        version: '2.0.2 –- 22 May, 2026 ',
        type: "fix",
        list: [
          "Fixed plugin guideline compliance issues.",
          "Improved readme structure and formatting.",
          "Minor improvements and fixes."
        ]
      },

      {
        version: '2.0.0 –- 17 Feb, 2026 ',
        type: "update",
        list: [
          "Universal Shortcodes: Compatible with all page builders.",
          "2+ Ready-to-Use Product Templates",
          "Admin Dashboard Updated"
        ]
      }
    ],
    proFeatures: [
      "Free + Pro Features: The Pro version includes everything that’s available in the free version.",
      "Universal Shortcodes: Compatible with all page builders.",
      "Templates: Includes 2+ ready-to-use templates.",
      "Element Visibility Control: Show or hide any product element as needed.",
      "Price & Discount Control: Manage product prices and discount tags easily.",
      "Color & Typography Settings: Customize colors and typography for all elements.",
      "Product Card Styling: Control background, padding, and shadow options.",
      "Image Customization: Adjust image width, height, and object-fit settings.",
      "Section Styling: Customize section padding, margin, and background.",
      "Review Count Display: Show review counts with styling options.",
      "Average Rating Display: Control rating colors and typography.",
      "Responsive Design: Fully responsive and mobile-friendly layout.",
      "Beginner-Friendly: Easy to use and simple to customize."
    ],

  };
}

export const demoInfo = {

  demos: [


    {
      title: 'Default',
      type: 'iframe',
      url: 'https://bblockswp.com/demo/default-recent-products/'
    },
    {
      title: 'Theme-1',
      type: 'iframe',
      url: 'https://bblockswp.com/demo/theme-1-recent-products/'
    },
    {
      title: 'Theme-2',
      type: 'iframe',
      url: 'https://bblockswp.com/demo/theme-2-recent-products/'
    }



  ]
}

export const pricingInfo = {
  logo: `${logo}`,
  pluginId: 23056,
  planId: 38798,
  licenses: [1, 3, null],
  button: {
    label: "Buy Now ➜",
  },
  featured: {
    selected: 3,
  },
};