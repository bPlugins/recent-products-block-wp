<?php
namespace WRP\Inc;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class GetCSS {

	static function isValidCSS( $property, $value ) {
		if ( empty( $value ) && $value !== '0' && $value !== 0 ) {
			return '';
		}
		return "$property: $value;";
	}

	static function getBackgroundCSS( $bg, $isSolid = true, $isGradient = true, $isImage = true ) {

		$type       = $bg['type'] ?? 'solid';
		$color      = $bg['color'] ?? '';
		$gradient   = $bg['gradient'] ?? 'linear-gradient(135deg, #0040E3, #18D4FD)';
		$image      = $bg['image'] ?? [];
		$position   = $bg['position'] ?? 'center center';
		$attachment = $bg['attachment'] ?? '';
		$repeat     = $bg['repeat'] ?? '';
		$size       = $bg['size'] ?? '';
		$overlay    = $bg['overlayColor'] ?? '';

		if ( 'gradient' === $type && $isGradient ) {
			$styles = self::isValidCSS( 'background', $gradient );

		} elseif ( 'image' === $type && $isImage ) {

			$imgUrl = esc_url( $image['url'] ?? '' );

			$styles =
				"background: url($imgUrl);" .
				self::isValidCSS( 'background-color', $overlay ) .
				self::isValidCSS( 'background-position', $position ) .
				self::isValidCSS( 'background-size', $size ) .
				self::isValidCSS( 'background-repeat', $repeat ) .
				self::isValidCSS( 'background-attachment', $attachment ) .
				"background-blend-mode: overlay;";

		} else {
			$styles = $isSolid ? self::isValidCSS( 'background', $color ) : '';
		}

		return $styles;
	}

	static function getBorderCSS( $border ) {

		$width  = $border['width'] ?? '0px';
		$style  = $border['style'] ?? 'solid';
		$color  = $border['color'] ?? '#0000';
		$side   = $border['side'] ?? 'all';
		$radius = $border['radius'] ?? '0px';

		$borderSideCheck = function( $s ) use ( $side ) {
			$bSide = strtolower( $side );
			return false !== strpos( $bSide, 'all' ) || false !== strpos( $bSide, $s );
		};

		$noWidth    = $width === '0px' || ! $width;
		$borderCSS  = "$width $style $color";
		$styles     = '';

		foreach ( [ 'top', 'right', 'bottom', 'left' ] as $s ) {
			if ( ! $noWidth && $borderSideCheck( $s ) ) {
				$styles .= "border-$s: $borderCSS;";
			}
		}

		if ( $radius ) {
			$styles .= "border-radius: $radius;";
		}

		return $styles;
	}

	static function getColorsCSS( $colors ) {

		$color     = $colors['color'] ?? '';
		$bgType    = $colors['bgType'] ?? 'solid';
		$bg        = $colors['bg'] ?? '';
		$gradient  = $colors['gradient'] ?? 'linear-gradient(135deg, #0040E3, #18D4FD)';

		$background = ( 'gradient' === $bgType ) ? $gradient : $bg;

		$styles  = self::isValidCSS( 'color', $color );
		$styles .= ( $gradient || $bg ) ? self::isValidCSS( 'background', $background ) : '';

		return $styles;
	}

	static function getShadowCSS( $shadow ) {

		$type     = $shadow['type'] ?? 'box';
		$hOffset  = $shadow['hOffset'] ?? '0px';
		$vOffset  = $shadow['vOffset'] ?? '0px';
		$blur     = $shadow['blur'] ?? '0px';
		$spread   = $shadow['spreed'] ?? '0px';
		$color    = $shadow['color'] ?? '#7090b0';
		$isInset  = $shadow['isInset'] ?? false;

		$inset       = $isInset ? 'inset' : '';
		$offsetBlur  = "$hOffset $vOffset $blur";

		$styles = ( 'text' === $type )
			? "$offsetBlur $color"
			: "$offsetBlur $spread $color $inset";

		return $styles ?: 'none';
	}

	static function checkUnit( $size ) {

		$value = (string) $size;
		$units = [ 'px', 'em', 'rem', '%', 'vh', 'vw' ];

		foreach ( $units as $unit ) {
			if ( substr( $value, -strlen( $unit ) ) === $unit ) {
				return $value;
			}
		}

		if ( is_numeric( $size ) ) {
			return $value . 'px';
		}

		return '';
	}

	static function getTypoCSS( $selector, $typo, $isFamily = true ) {

		$fontFamily     = $typo['fontFamily'] ?? 'Default';
		$fontCategory   = $typo['fontCategory'] ?? 'sans-serif';
		$fontVariant    = $typo['fontVariant'] ?? 400;
		$fontWeight     = $typo['fontWeight'] ?? '';
		$isUploadFont   = $typo['isUploadFont'] ?? true;

		$fontSize = $typo['fontSize'] ?? [
			'desktop' => null,
			'tablet'  => null,
			'mobile'  => null
		];

		$fontStyle      = $typo['fontStyle'] ?? '';
		$textTransform  = $typo['textTransform'] ?? '';
		$textDecoration = $typo['textDecoration'] ?? '';
		$lineHeight     = $typo['lineHeight'] ?? '';
		$letterSpace    = $typo['letterSpace'] ?? '';

		$isEmptyFamily   = ! $isFamily || ! $fontFamily || 'Default' === $fontFamily;

		$desktop = $fontSize['desktop'] ?? $fontSize;
		$tablet  = $fontSize['tablet'] ?? $desktop;
		$mobile  = $fontSize['mobile'] ?? $tablet;

		$tabBreakpoint    = '@media only screen and (max-width: 1024px)';
		$mobileBreakpoint = '@media only screen and (max-width: 640px)';

		$styles =
			( $isEmptyFamily ? '' : "font-family: '$fontFamily', $fontCategory;" ) .
			self::isValidCSS( 'font-weight', $fontWeight ) .
			self::isValidCSS( 'font-size', self::checkUnit( $desktop ) ) .
			self::isValidCSS( 'font-style', $fontStyle ) .
			self::isValidCSS( 'text-transform', $textTransform ) .
			self::isValidCSS( 'text-decoration', $textDecoration ) .
			self::isValidCSS( 'line-height', $lineHeight ) .
			self::isValidCSS( 'letter-spacing', $letterSpace );

		// Google Font URL (ESCAPED)
		if ( ! $fontVariant || $fontVariant === 400 ) {
			$linkQuery = '';
		} elseif ( $fontVariant === '400i' ) {
			$linkQuery = ':ital@1';
		} elseif ( strpos( $fontVariant, '00i' ) !== false ) {
			$linkQuery = ':ital,wght@1,' . str_replace( '00i', '00', $fontVariant );
		} else {
			$linkQuery = ":wght@$fontVariant";
		}

		$fontUrl = '';
		if ( ! $isEmptyFamily ) {
			$rawUrl  = 'https://fonts.googleapis.com/css2?family=' .
				str_replace( ' ', '+', $fontFamily ) .
				$linkQuery .
				'&display=swap';

			$fontUrl = esc_url( $rawUrl );
		}

		return [
			'googleFontLink' => ( ! $isUploadFont || $isEmptyFamily )
				? ''
				: "@import url($fontUrl);",

			'styles' => preg_replace(
				'/\s+/',
				' ',
				trim("
					$selector { $styles }

					$tabBreakpoint {
						$selector { " . self::isValidCSS( 'font-size', self::checkUnit( $tablet ) ) . " }
					}

					$mobileBreakpoint {
						$selector { " . self::isValidCSS( 'font-size', self::checkUnit( $mobile ) ) . " }
					}
				")
			)
		];
	}

	static function getBoxCSS( $margin ) {
		return ($margin['top'] ?? '0px') . ' ' .
		       ($margin['right'] ?? '0px') . ' ' .
		       ($margin['bottom'] ?? '0px') . ' ' .
		       ($margin['left'] ?? '0px');
	}

	static function getMuiltShadowCSS( $shadow ) {

		if ( empty( $shadow ) || ! is_array( $shadow ) ) {
			return 'none';
		}

		$shadow    = $shadow[0];
		$type      = $shadow['type'] ?? 'box';
		$hOffset   = $shadow['hOffset'] ?? '0px';
		$vOffset   = $shadow['vOffset'] ?? '0px';
		$blur      = $shadow['blur'] ?? '0px';
		$spread    = $shadow['spreed'] ?? '0px';
		$color     = $shadow['color'] ?? '#7090b0';
		$isInset   = $shadow['isInset'] ?? false;

		$inset = $isInset ? 'inset' : '';
		$offset = "$hOffset $vOffset $blur";

		return ( 'text' === $type )
			? "$offset $color"
			: "$offset $spread $color $inset";
	}
}