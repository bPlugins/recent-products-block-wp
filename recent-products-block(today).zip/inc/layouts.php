<?php
namespace WRP\Inc;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// File: inc/WRPTest.php

class layouts
{

    // Static method for simple inline test card



}
